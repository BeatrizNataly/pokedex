package com.projeto.pokedex.pokedex.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo_Type;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.Type;
import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.List;

@Dao
public interface PokedexDao {

    //Pokemon
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addPokemon(Pokemon pokemon);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addAllPokemons(List<Pokemon> pokemons);

    @Query("SELECT * FROM tb_pokemon")
    List<Pokemon> getPokemonsDoDatabase();

    @Query("SELECT * FROM tb_pokemon WHERE name LIKE '%' || :pokemon || '%'")
    List<Pokemon> searchPokemonsFromDatabase(String pokemon);

    //PokeInfo
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addPokeInfo(PokeInfo pokeInfo);

    @Query("SELECT id, name, height, weight FROM tb_pokeInfo")
    PokeInfo getPokeInfoFromDatabase();

    //Type
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addType(Type tipo);

    //  Pega tipos do banco com base no id do Pokemon ao qual estão associados
    @Query("SELECT DISTINCT ti.nomeTipo FROM tb_type AS ti " +
            "INNER JOIN tb_pokeInfo_Type AS pit ON TI.idTipo = PIT.fk_type " +
            "WHERE fk_pokeInfo = :idPokeInfo")
    List<String> getTypesFromDatabase(int idPokeInfo);

    //PokeInfo_Type
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addRelationPokeInfoType(PokeInfo_Type pokeInfo_type);

    /*
    TO DO:

    - Implementar mudança (pokeinfo + tipos) do database no código principal
    - Criar classe para representar habilidades e pokeinfo_habilidades
    - Implementar mudança (pokeinfo + habilidades)
    - Revisar código
    - Refatorar código
    - Repetir
     */
}
