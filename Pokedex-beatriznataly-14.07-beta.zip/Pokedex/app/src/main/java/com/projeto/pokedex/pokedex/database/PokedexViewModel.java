package com.projeto.pokedex.pokedex.database;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo_Type;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.Type;
import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.List;

public class PokedexViewModel extends AndroidViewModel {
    PokedexDao dao;

    public PokedexViewModel(@NonNull Application application) {
        super(application);
        PokedexDatabase database = PokedexDatabase.getInstance(application.getApplicationContext());
        dao = database.getPokedexDao();
    }

    //Pokemon
    public List<Pokemon> getPokemonsDoDatabase(){
        return dao.getPokemonsDoDatabase();
    }

    public void addAllPokemonsToDatabase(List<Pokemon> pokemons){ dao.addAllPokemons(pokemons); }

    public List<Pokemon> searchPokemonsFromDatabase(String pokemon){ return dao.searchPokemonsFromDatabase(pokemon); }

    //PokeInfo
    public void addPokeInfoToDatabase(PokeInfo pokeInfo){ dao.addPokeInfo(pokeInfo); }

    public PokeInfo getPokeInfoFromDatabase(){ return dao.getPokeInfoFromDatabase(); }

    //Type
    public void addTypeToDatabase(Type type){ dao.addType(type); }

    public List<String> getPokemonTypesFromDatabase(int idPokemon){ return dao.getTypesFromDatabase(idPokemon); }

    //PokeInfo_Type
    public void addRelationPokeInfoType(PokeInfo_Type pokeInfo_type){ dao.addRelationPokeInfoType(pokeInfo_type);}

    //Logi
    private void verificaPokemonsNoDatabase() {
        for(Pokemon p: dao.getPokemonsDoDatabase()){
            Log.i("POKEMON NO DB: ", "ID:" + p.getNumber() + "\n NOME: " + p.getName());
        }
    }

    private void verificaBuscaPokemonsNoDatabase(String busca) {
        Log.i("TERMO DE BUSCA: ", busca + "\n");
        for(Pokemon p: dao.searchPokemonsFromDatabase(busca)){
            Log.i("POKEMON NA BUSCA: ", "ID:" + p.getNumber() + "\n NOME: " + p.getName());
        }
    }

//    private void verificaTiposNoDatabase(){
//        for(Type t: dao.getTypesFromDatabase())
//        Log.i("TYPE ->", "" + t.getNomeTipo());
//    }
}
