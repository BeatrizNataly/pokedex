package com.projeto.pokedex.pokedex.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo_Type;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.Type;
import com.projeto.pokedex.pokedex.entities.Pokemon;
import com.projeto.pokedex.pokedex.entities.PokemonInfo;

@Database(entities = {Pokemon.class, PokeInfo.class, Type.class, PokeInfo_Type.class}, exportSchema = false, version = 3)
public abstract class PokedexDatabase extends RoomDatabase {

    public abstract PokedexDao getPokedexDao();

    public static PokedexDatabase getInstance(Context contexto) {
        return Room.databaseBuilder(contexto, PokedexDatabase.class, "pokedex.db")
                .allowMainThreadQueries()
            //    .fallbackToDestructiveMigration()
                .build();
    }

}
