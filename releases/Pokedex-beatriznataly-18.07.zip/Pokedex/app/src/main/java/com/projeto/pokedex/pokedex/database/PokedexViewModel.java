package com.projeto.pokedex.pokedex.database;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.projeto.pokedex.pokedex.database.pokeinfo.tables.Ability;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo_Ability;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.PokeInfo_Type;
import com.projeto.pokedex.pokedex.database.pokeinfo.tables.Type;
import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.List;

public class PokedexViewModel extends AndroidViewModel {
    PokedexDao dao;

    public PokedexViewModel(@NonNull Application application) {
        super(application);
        PokedexDatabase database = PokedexDatabase.getInstance(application.getApplicationContext());
        dao = database.getPokedexDao();
    }

    //Pokemon
    public List<Pokemon> getPokemonsDoDatabase(){
        return dao.getPokemonsDoDatabase();
    }

    public void addAllPokemonsToDatabase(List<Pokemon> pokemons){ dao.addAllPokemons(pokemons); }

    public List<Pokemon> searchPokemonsFromDatabase(String pokemon){ return dao.searchPokemonsFromDatabase(pokemon); }

    //PokeInfo
    public void addPokeInfoToDatabase(PokeInfo pokeInfo){ dao.addPokeInfo(pokeInfo); }

    public PokeInfo getPokeInfoFromDatabase(int id){ return dao.getPokeInfoFromDatabase(id); }

    //Type
    public void addTypeToDatabase(Type type){ dao.addType(type); }

    public List<Type> getPokemonTypesFromDatabase(int idPokemon){ return dao.getTypesFromDatabase(idPokemon); }

    //PokeInfo_Type
    public void addRelationPokeInfoType(PokeInfo_Type pokeInfo_type){ dao.addRelationPokeInfoType(pokeInfo_type);}

    //Ability
    public void addAbilityToDatabase(Ability ability){ dao.addAbility(ability); }

    public List<Ability> getPokemonAbilitiesFromDatabase(int idPokemon){
        verificaHabilidadeNoDB(idPokemon);
        return dao.getAbilitiesFromDatabase(idPokemon);
    }

    //PokeInfo_Ability
    public void addRelationPokeInfoAbility(PokeInfo_Ability pokeInfo_ability){ dao.addRelationPokeInfoAbility(pokeInfo_ability); }

    //Logi
    private void verificaPokemonsNoDatabase() {
        for(Pokemon p: dao.getPokemonsDoDatabase()){
            Log.i("POKEMON NO DB: ", "ID:" + p.getNumber() + "\n NOME: " + p.getName());
        }
    }

    private void verificaBuscaPokemonsNoDatabase(String busca) {
        Log.i("TERMO DE BUSCA: ", busca + "\n");
        for(Pokemon p: dao.searchPokemonsFromDatabase(busca)){
            Log.i("POKEMON NA BUSCA: ", "ID:" + p.getNumber() + "\n NOME: " + p.getName());
        }
    }

//    private void verificaTiposNoDatabase(){
//        for(Type t: dao.getTypesFromDatabase())
//        Log.i("TYPE ->", "" + t.getNomeTipo());
//    }

    private void verificaHabilidadeNoDB(int idPokemon) {
        for(Ability a: dao.getAbilitiesFromDatabase(idPokemon)){
            Log.i("ABILITY DB: ", "" + a.getId() + " - " + a.getNomeAbility());
        }
    }
}
