package com.projeto.pokedex.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.projeto.pokedex.R;
import com.projeto.pokedex.recyclerview.adapter.viewPager.ViewPagerAdapter;
import com.projeto.pokedex.util.ConstantUtil;

public class MainActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private SwipeRefreshLayout swipeRefreshLayout;
    private EditText pesquisa;
    private TextView arrowBack;
    private ListaPokemonFragment listaPokemonFragment;
    private ListaFavoritosFragment listaFavoritosFragment;
    private int tabIcons[] = {R.drawable.pokeball, R.drawable.ic_favorite};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Pokédex");
        setViews();
        setLayoutManager();
    }

    private void setViews() {
        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.main_view_pager);
        listaPokemonFragment = new ListaPokemonFragment();
        listaFavoritosFragment = new ListaFavoritosFragment();
        arrowBack = findViewById(R.id.back_to_list);
    }

    private void setLayoutManager() {
        setupViewPagerAdapter();
        setupTabIcons();
    }

    private void setupViewPagerAdapter() {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle());
        viewPagerAdapter.adicionaFragmento(listaPokemonFragment, "Pokémons");
        viewPagerAdapter.adicionaFragmento(listaFavoritosFragment, "Favoritos");
        viewPager.setAdapter(viewPagerAdapter);

        new TabLayoutMediator(tabLayout,
                viewPager,
                (tab, position) ->
                        tab.setText(viewPagerAdapter.getTituloFragment(position))
        ).attach();
    }

    private void setupTabIcons() {
        tabLayout.getTabAt(0).setIcon(tabIcons[0]);
        tabLayout.getTabAt(1).setIcon(tabIcons[1]);
    }

    public void buscaPokemon(View view){ //AJUSTAR
        pesquisa = findViewById(R.id.editTextPesquisaNomePokemon);
        String busca = pesquisa.getText().toString();
        if(!busca.isEmpty()) {
            arrowBack.setVisibility(View.VISIBLE);
            listaPokemonFragment.buscaPokemon(busca);
 //           listaFavoritosFragment.buscaNosFavoritos(busca);
        }
        Toast.makeText(this, ConstantUtil.POKEMON_NOT_FOUND, Toast.LENGTH_SHORT).show();
    }

    public void scrollUp(View view) {
        listaPokemonFragment.scrollUp();
    }

    public void retornaParaListaPrincipal(View view){ //AJUSTAR
        arrowBack.setVisibility(View.GONE);
        pesquisa.setText(""); //limpa pesquisa
        listaPokemonFragment.retornaParaListaPrincipal();
        Toast.makeText(this, ConstantUtil.RETURN, Toast.LENGTH_SHORT).show();
    }
}
