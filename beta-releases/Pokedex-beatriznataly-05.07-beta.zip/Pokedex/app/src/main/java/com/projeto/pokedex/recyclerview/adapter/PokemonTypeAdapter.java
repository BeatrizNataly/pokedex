package com.projeto.pokedex.recyclerview.adapter;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.entities.PokemonInfo;
import com.projeto.pokedex.util.ColorUtil;
import com.projeto.pokedex.util.ConstantUtil;

import java.util.ArrayList;

public class PokemonTypeAdapter extends RecyclerView.Adapter<com.projeto.pokedex.recyclerview.adapter.PokemonTypeAdapter.ViewHolder> {
    private ArrayList<PokemonInfo.Types> listaType;

    public PokemonTypeAdapter(){
        this.listaType = new ArrayList<>();
    }

    @NonNull
    @Override
    public PokemonTypeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recyclerview_info, parent, false);
        return new PokemonTypeAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.typeTextView.setText(listaType.get(position).getType().getName().toUpperCase());
        int type = listaType.get(position).getType().getNumber();
        setColorType(holder, type);
    }

    @Override
    public int getItemCount() {
        return listaType.size();
    }

    private void setColorType(ViewHolder holder, int type){
        Drawable background = holder.typeContainerImageView.getBackground();
        Drawable pokeball = holder.logoImageView.getBackground();
        int viewColor = ColorUtil.getForegroundViewColor(type);

        background.setColorFilter(ColorUtil.getBackgroundColor(type), PorterDuff.Mode.MULTIPLY);
        holder.typeTextView.setTextColor(viewColor);
        pokeball.setColorFilter(viewColor, PorterDuff.Mode.SRC_IN);
    }

    public void adicionaLista(ArrayList<PokemonInfo.Types> lista) {
        if (lista != null) {
            this.listaType.addAll(lista);
            notifyDataSetChanged();
        } else {
            Log.i(ConstantUtil.POKEDEX_ERRO, lista.toString());
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder{
            private ImageView logoImageView, typeContainerImageView;
            private TextView typeTextView;

            public ViewHolder(View view){
                super(view);
                logoImageView = view.findViewById(R.id.item_topic_vector);
                typeTextView = view.findViewById(R.id.item_topic_texto);
                typeContainerImageView = view.findViewById(R.id.item_topic_container);
            }
        }
}
