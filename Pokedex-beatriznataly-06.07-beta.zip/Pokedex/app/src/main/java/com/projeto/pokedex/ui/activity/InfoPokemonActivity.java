package com.projeto.pokedex.ui.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.api.PokedexApiService;
import com.projeto.pokedex.pokedex.api.PokemonRetrofit;
import com.projeto.pokedex.pokedex.entities.Pokemon;
import com.projeto.pokedex.pokedex.entities.PokemonInfo;
import com.projeto.pokedex.recyclerview.adapter.PokemonAbilityAdapter;
import com.projeto.pokedex.recyclerview.adapter.PokemonTypeAdapter;
import com.projeto.pokedex.ui.animation.LoadingAnimation;
import com.projeto.pokedex.util.ConstantUtil;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InfoPokemonActivity extends AppCompatActivity {

    private static final String APP_TITLE_INFO = "Sobre o pokémon";
    private AnimationDrawable animationDrawable;
    private TextView nomePokemon, pesoAlturaPokemon, noConnection, habilidadesTextView;
    private RecyclerView abilitiesRecyclerview, typeRecyclerview;
    private ImageView imagemPokemon;
    private PokemonRetrofit retrofit;
    private int pokemonId;
    private PokemonAbilityAdapter adapterAbility;
    private PokemonTypeAdapter adapterType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_pokemon);
        setTitle(APP_TITLE_INFO);
        getViews();
        getRetrofit();
        getPokemon();
       // createLoadingAnimation();
    }

    private void createLoadingAnimation() {
        ImageView loading = findViewById(R.id.loading_info);
        TextView loadingText = findViewById(R.id.loading_text_view_info);
        animationDrawable = (AnimationDrawable) loading.getDrawable();
        animationDrawable.start();
        LoadingAnimation.delayFadeOut(loading, animationDrawable, loadingText);
    }

    private void getRetrofit() {
        retrofit = new PokemonRetrofit(this);
        retrofit.createRetrofit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menu_item_arrow_back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void getPokemon() {
        if(getIntent().getSerializableExtra("extra_pokemon") != null){
            Pokemon pokemon = (Pokemon) getIntent().getSerializableExtra("extra_pokemon");
            nomePokemon.setText(pokemon.getName().toUpperCase());
            pokemonId = pokemon.getNumber();
            setFotoPokemon();
            getInfosDaApi();
        } else {
            Toast.makeText(this,ConstantUtil.POKEMON_NOT_FOUND, Toast.LENGTH_SHORT).show();
        }
    }

    private void setFotoPokemon() {
        Glide.with(this)
                .load(ConstantUtil.IMAGE_BASE_URL + pokemonId + ".png")
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imagemPokemon);
    }

    private void getViews() {
        noConnection = findViewById(R.id.info_sem_conexao);
        noConnection.setVisibility(View.GONE);

        habilidadesTextView = findViewById(R.id.info_tipo);
        habilidadesTextView.setVisibility(View.VISIBLE);

        nomePokemon = findViewById(R.id.placeholder_nome_pokemon);
        pesoAlturaPokemon = findViewById(R.id.info_peso_altura);
        imagemPokemon = findViewById(R.id.info_imagem_pokemon);

        createRecyclerViews();
    }

    private void createRecyclerViews() {
        LinearLayoutManager linearLayoutManager;
        GridLayoutManager gridLayoutManager;

        adapterAbility = new PokemonAbilityAdapter(this);
        abilitiesRecyclerview = findViewById(R.id.info_recyclerview_ability);
        abilitiesRecyclerview.setHasFixedSize(true);
        linearLayoutManager = new LinearLayoutManager(this);
        abilitiesRecyclerview.setLayoutManager(linearLayoutManager);
        abilitiesRecyclerview.setAdapter(adapterAbility);

        adapterType = new PokemonTypeAdapter();
        typeRecyclerview = findViewById(R.id.info_pokemon_type);
        typeRecyclerview.setHasFixedSize(true);
        gridLayoutManager = new GridLayoutManager(this, 2);
        typeRecyclerview.setLayoutManager(gridLayoutManager);
        typeRecyclerview.setAdapter(adapterType);
    }

    private void getInfosDaApi() {
        PokedexApiService apiService = retrofit.getRetrofit().create(PokedexApiService.class);
        Call<PokemonInfo> callback = apiService.getInfoPokemon(pokemonId);
        callback.enqueue(new Callback<PokemonInfo>() {
            @SuppressLint("LongLogTag")
            @Override
            public void onResponse(Call<PokemonInfo> call, Response<PokemonInfo> response) {
                if(response.isSuccessful()){ //insere dados com base na API
                    PokemonInfo body = response.body();
                    String pesoAltura = "Peso: " + retrofit.formatMedida(body.getWeight(), "kg")
                            + " - Altura: " + retrofit.formatMedida(body.getHeight(), "m");

                    adapterAbility.adicionaListaAbilities((ArrayList<PokemonInfo.Ability>) body.getAbilities());
                    adapterType.adicionaLista((ArrayList<PokemonInfo.Types>) body.getTypes());
                   // nomePokemon.setText(body.getName().toUpperCase());
                    pesoAlturaPokemon.setText(pesoAltura);
                } else {
                    Log.i(ConstantUtil.ERRO_AO_CARREGAR_LISTA, "-> onResponse: " + response.errorBody());
                }
            }
            @SuppressLint("LongLogTag")
            @Override
            public void onFailure(Call<PokemonInfo> call, Throwable t) {
                Log.i(ConstantUtil.NO_CONNECTION, "-> onResponse: " + t.getMessage());
                noConnection.setVisibility(View.VISIBLE);
                habilidadesTextView.setVisibility(View.GONE);
            }
        });
    }

    public void finishBtn(View view) {
        finish();
    }
}