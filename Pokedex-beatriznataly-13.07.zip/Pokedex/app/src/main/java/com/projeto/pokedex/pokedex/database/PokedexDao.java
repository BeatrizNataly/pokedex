package com.projeto.pokedex.pokedex.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.List;

@Dao
public interface PokedexDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addPokemon(Pokemon pokemon);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addAllPokemons(List<Pokemon> pokemons);

    @Query("SELECT * FROM tb_pokemon")
    List<Pokemon> getPokemonsDoDatabase();

    @Query("SELECT * FROM tb_pokemon WHERE name LIKE '%' || :pokemon || '%'")
    List<Pokemon> searchPokemonsFromDatabase(String pokemon);
}
