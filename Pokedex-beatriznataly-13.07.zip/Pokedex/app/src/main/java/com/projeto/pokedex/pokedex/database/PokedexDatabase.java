package com.projeto.pokedex.pokedex.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.projeto.pokedex.pokedex.entities.Pokemon;

@Database(entities = {Pokemon.class}, exportSchema = false, version = 1)
public abstract class PokedexDatabase extends RoomDatabase {

    public abstract PokedexDao getPokedexDao();

    public static PokedexDatabase getInstance(Context contexto) {
        return Room.databaseBuilder(contexto, PokedexDatabase.class, "pokedex.db")
                .allowMainThreadQueries()
                .build();
    }

}
