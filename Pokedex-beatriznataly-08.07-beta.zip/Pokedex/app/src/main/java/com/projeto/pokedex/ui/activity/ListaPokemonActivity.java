package com.projeto.pokedex.ui.activity;

import static android.view.View.GONE;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.api.PokemonRetrofit;
import com.projeto.pokedex.pokedex.database.PokedexViewModel;
import com.projeto.pokedex.recyclerview.adapter.ListaPokemonAdapter;
import com.projeto.pokedex.util.ConstantUtil;

public class ListaPokemonActivity extends AppCompatActivity {
    private FloatingActionButton fabScroll;
    private ProgressBar spinner;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView listaPokemonsRecyclerView;
    private EditText pesquisa;
    private  GridLayoutManager gridLayoutManager;
    private PokemonRetrofit retrofit;
    private ListaPokemonAdapter adapter;
    private PokedexViewModel viewModel;
    private boolean isScrolledToEnd;
    private ImageView arrowBack;
    private int offset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_pokemon);
        adapter = new ListaPokemonAdapter(this);
        retrofit = new PokemonRetrofit(this);

        // createLoadingAnimation(); //Crashing --NullPointerException (A corrigir)
        createRecyclerView();
        createViewModel();
        createRetrofit();
        createScrollListener();
        createRefreshLayout();
    }

    private void createLoadingAnimation() {
        spinner.findViewById(R.id.spinner_lista_pokemon_activity);
        spinner.setVisibility(View.VISIBLE);

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> spinner.setVisibility(View.GONE), 300);
    }

    private void createRefreshLayout() { //RECARREGA A LISTA DO ZERO E EXIBE O RESULTADO CARREGADO
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(() -> {
            listaPokemonsRecyclerView.setVisibility(View.INVISIBLE);
            scrollUp(findViewById(R.id.fab_scroll_up_main));
           // createLoadingAnimation();
            listaPokemonsRecyclerView.setVisibility(View.VISIBLE);
            getInformacao(offset);
            swipeRefreshLayout.setRefreshing(false);
        });
    }

    private void createViewModel() {
        viewModel = ViewModelProviders.of(this).get(PokedexViewModel.class);
    }

    private void createRetrofit() {
        retrofit.createRetrofit();
        isScrolledToEnd = true;
        offset = 0;
        getInformacao(offset);
    }

    private void createRecyclerView() {
        arrowBack = findViewById(R.id.back_to_list);

        listaPokemonsRecyclerView = findViewById(R.id.pokemon_recyclerview);
        listaPokemonsRecyclerView.setAdapter(adapter);
        listaPokemonsRecyclerView.setHasFixedSize(true);
        gridLayoutManager = new GridLayoutManager(this, 2);
        listaPokemonsRecyclerView.setLayoutManager(gridLayoutManager);
    }

    private void createScrollListener() {
        listaPokemonsRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if(dy > 0){
                    int itemVisivelCount = gridLayoutManager.getChildCount();
                    int totalItemCount = gridLayoutManager.getItemCount();
                    int ultimoItemVisivel = gridLayoutManager.findFirstVisibleItemPosition();
                    /*
                    verifica se há conexão com a internet antes de recarregar o offset,
                    evitando que ele recarregue a mesma lista offline.
                     */
                    if(retrofit.isApiOnline())
                        //detecta que chegamos ao final da lista e carrega + 20 itens em sua visualização.
                    if((itemVisivelCount + ultimoItemVisivel) >= totalItemCount){
                        isScrolledToEnd = false;
                        offset += 20;
                        if(arrowBack.getVisibility() == GONE)
                        getInformacao(offset);
                    }
                }
            }
        });
    }

    private void getInformacao(int offset) {
        isScrolledToEnd = true;
        arrowBack.setVisibility(View.GONE);
        retrofit.getListaDaAPI(offset, adapter, viewModel);
    }

    public void buscaPokemon(View view){
        pesquisa = findViewById(R.id.editTextPesquisaNomePokemon);
        String busca = pesquisa.getText().toString();
        if(!busca.isEmpty()) {
            arrowBack.setVisibility(View.VISIBLE);
            retrofit.getBusca(offset, adapter, busca);
            return;
        }
        Toast.makeText(this, ConstantUtil.POKEMON_NOT_FOUND, Toast.LENGTH_SHORT).show();

    }

    public void retornaParaListaPrincipal(View view){
        adapter.limpaLista();
        offset = 0;
        getInformacao(offset);
        Toast.makeText(this, ConstantUtil.RETURN, Toast.LENGTH_SHORT).show();
    }

    public void scrollUp(View view) {
        LinearLayoutManager layoutManager = (LinearLayoutManager) listaPokemonsRecyclerView.getLayoutManager();
        layoutManager.smoothScrollToPosition(listaPokemonsRecyclerView, null, 0);
    }
}