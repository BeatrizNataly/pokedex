package com.projeto.pokedex.pokedex.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.projeto.pokedex.pokedex.callback.PokemonCallBack;
import com.projeto.pokedex.pokedex.database.PokedexViewModel;
import com.projeto.pokedex.pokedex.entities.Pokemon;
import com.projeto.pokedex.recyclerview.adapter.ListaPokemonAdapter;
import com.projeto.pokedex.util.ConstantUtil;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PokemonRetrofit {
    private boolean responseState;
    private static Retrofit retrofit;
    private static PokedexApiService apiService;
    private PokedexViewModel viewModel;
    private Context context;

    public PokemonRetrofit(Context context){
        this.context = context;
    }

    public Retrofit createRetrofit() {
        return this.retrofit = new Retrofit.Builder()
                .baseUrl(ConstantUtil.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public void setViewModel(PokedexViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public PokedexViewModel getViewModel(){ return viewModel; }

    public void getListaDaAPI(int offset, ListaPokemonAdapter adapter) {
        apiService = retrofit.create(PokedexApiService.class);
        Call<PokemonCallBack> callback = apiService.getListaPokemons(20, offset);
        callback.enqueue(new Callback<PokemonCallBack>() {
            @SuppressLint("LongLogTag")
            @Override
            public void onResponse(Call<PokemonCallBack> call, Response<PokemonCallBack> response) {
                if(response.isSuccessful()){ //busca lista da API e insere no adapter
                    responseState = true;
                    PokemonCallBack body = response.body();
                    ArrayList<Pokemon> result = body.getResults();
                    adapter.adicionaLista(result);
                    viewModel.addAllPokemonsToDatabase(result);
                } else { //busca lista do banco de dados e insere no adapter
                    responseState = false;
                    Log.i(ConstantUtil.ERRO_AO_CARREGAR, "-> onResponse: " + response.errorBody());
                    Toast.makeText(context, ConstantUtil.ERRO_AO_CARREGAR, Toast.LENGTH_LONG).show();
                    adapter.adicionaLista((ArrayList<Pokemon>) viewModel.getPokemonsDoDatabase());
                }
            }
            @SuppressLint("LongLogTag")
            @Override
            public void onFailure(Call<PokemonCallBack> call, Throwable t) { //busca lista do banco de dados e insere no adapter
                responseState = false;
                Log.i(ConstantUtil.NO_CONNECTION, "-> onFailure: " + t.getMessage());
                Toast.makeText(context, ConstantUtil.NO_CONNECTION, Toast.LENGTH_LONG).show();
                adapter.adicionaLista((ArrayList<Pokemon>)viewModel.getPokemonsDoDatabase());
            }
        });
    }

    public void getBusca(int offset, ListaPokemonAdapter adapter, String busca){
        apiService = retrofit.create(PokedexApiService.class);
        Call<PokemonCallBack> callback = apiService.getListaPokemons(15000, offset);
        callback.enqueue(new Callback<PokemonCallBack>() {
            @SuppressLint("LongLogTag")
            @Override
            public void onResponse(Call<PokemonCallBack> call, Response<PokemonCallBack> response) {
                if(response.isSuccessful()){
                    responseState = true;
                    PokemonCallBack body = response.body();
                    ArrayList<Pokemon> result = body.getResults();
                    ArrayList<Pokemon> searchResult = new ArrayList<>();
                    for(Pokemon p: result){
                        if(p.getName().contains(busca.toLowerCase())){
                            searchResult.add(p);
                        }
                    }
                    adapter.adicionaListaDeBusca(searchResult);
                } else {
                    responseState = false;
                    Toast.makeText(context, ConstantUtil.NO_CONNECTION, Toast.LENGTH_SHORT).show();
                    ArrayList<Pokemon> result = (ArrayList<Pokemon>) viewModel.searchPokemonsFromDatabase(busca);
                    if(result.size() > 0)
                        adapter.adicionaListaDeBusca(result);
                }
            }
            @SuppressLint("LongLogTag")
            @Override
            public void onFailure(Call<PokemonCallBack> call, Throwable t) {
                responseState = false;
                Toast.makeText(context, ConstantUtil.NO_CONNECTION, Toast.LENGTH_SHORT).show();
                ArrayList<Pokemon> result = (ArrayList<Pokemon>) viewModel.searchPokemonsFromDatabase(busca);
                if(result.size() > 0)
                    adapter.adicionaListaDeBusca(result);
            }
        });
    }

    public String formatMedida(int atributo, String medida){
        String format = "" + atributo;
        if(format.length() == 1)
            return "0," + atributo + medida;
        return format.substring(0, format.length()-1) + "," + format.charAt(format.length()-1) + medida;
    }

    public boolean isApiOnline(){
        return responseState;
    }

    public Retrofit getRetrofit() {
        return retrofit;
    }
}
