package com.projeto.pokedex.pokedex.database;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.ArrayList;
import java.util.List;

public class PokedexViewModel extends AndroidViewModel {
    PokedexDao dao;

    public PokedexViewModel(@NonNull Application application) {
        super(application);
        PokedexDatabase database = PokedexDatabase.getInstance(application.getApplicationContext());
        dao = database.getPokedexDao();
    }

    public List<Pokemon> getPokemonsDoDatabase(){
        return dao.getPokemonsDoDatabase();
    }

    public void addAllPokemonsToDatabase(List<Pokemon> pokemons){
        dao.addAllPokemons(pokemons);
//        for(Pokemon p: dao.getPokemonsDoDatabase()){
//            Log.i("POKEMON NO DB: ", "ID:" + p.getNumber() + "\n NOME: " + p.getName());
//        }
    }
}
