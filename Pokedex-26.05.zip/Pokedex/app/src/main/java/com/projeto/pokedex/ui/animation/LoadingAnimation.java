package com.projeto.pokedex.ui.animation;

import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

public class LoadingAnimation {
    public static void delayFadeOut(ImageView loading, AnimationDrawable animationDrawable, TextView loadingText) {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fadeOutAnimation(loading, loadingText);
                animationDrawable.stop();
            }
        }, 1000);
    }

    private static void fadeOutAnimation(ImageView loading, TextView loadingText) {
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setDuration(1000);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd(Animation animation) {
                loading.setVisibility(View.GONE);
                loadingText.setVisibility(View.GONE);
            }
            public void onAnimationRepeat(Animation animation) {}
            public void onAnimationStart(Animation animation) {}
        });

        loading.startAnimation(fadeOut);
        loadingText.startAnimation(fadeOut);
    }
}
