package com.projeto.pokedex.recyclerview.adapter;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.entities.PokemonInfo;
import com.projeto.pokedex.util.ConstantUtil;

import java.util.ArrayList;

public class PokemonAbilityAdapter extends RecyclerView.Adapter<PokemonAbilityAdapter.ViewHolderAbility> {
    private ArrayList<PokemonInfo.Ability> listaAbility;
    private Activity activity;
    private Context context;

    public PokemonAbilityAdapter(Activity activity){
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.listaAbility = new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolderAbility onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recyclerview_info, parent, false);
        return new ViewHolderAbility(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderAbility holder, int position) {
        holder.abilityTextView.setText(listaAbility.get(position).getAbilityInfo().getName().toUpperCase());
    }

    @Override
    public int getItemCount() {
        return listaAbility.size();
    }

    public void adicionaListaAbilities(ArrayList<PokemonInfo.Ability> lista) {
        if (lista != null) {
            this.listaAbility.addAll(lista);
            notifyDataSetChanged();
        } else {
            Log.i(ConstantUtil.POKEDEX_ERRO, lista.toString());
        }
    }

    class ViewHolderAbility extends RecyclerView.ViewHolder{
        private ImageView abilityImagemView, typeContainerImageView;
        private TextView abilityTextView, typeTextView;

        public ViewHolderAbility(View view){
            super(view);
            abilityImagemView = view.findViewById(R.id.item_topic_vector);
            abilityTextView = view.findViewById(R.id.item_topic_texto);
            typeContainerImageView = view.findViewById(R.id.item_topic_container);
        }
    }
}
