package com.projeto.pokedex.ui.activity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.PokemonRetrofit;
import com.projeto.pokedex.recyclerview.adapter.ListaPokemonAdapter;
import com.projeto.pokedex.util.ConstantUtil;
import com.projeto.pokedex.ui.animation.LoadingAnimation;

public class ListaPokemonActivity extends AppCompatActivity {
    private FloatingActionButton fabScroll;
    private AnimationDrawable animationDrawable;
    private RecyclerView listaPokemonsRecyclerView;
    private  GridLayoutManager gridLayoutManager;
    private PokemonRetrofit retrofit;
    private ListaPokemonAdapter adapter;
    private boolean isScrolledToEnd;
    private int offset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_pokemon);
        adapter = new ListaPokemonAdapter(this);
        retrofit = new PokemonRetrofit(this);

        createRecyclerView();
        createRetrofit();
        createScrollListener();
        createLoadingAnimation();
    }

    private void createLoadingAnimation() {
        ImageView loading = findViewById(R.id.loading_main);
        TextView loadingText = findViewById(R.id.loading_text_view_main);
        animationDrawable = (AnimationDrawable) loading.getDrawable();
        animationDrawable.start();
        LoadingAnimation.delayFadeOut(loading, animationDrawable, loadingText);
    }



    private void createRetrofit() {
        retrofit.createRetrofit();
        isScrolledToEnd = true;
        offset = 0;
        getInformacao(offset);
    }

    private void createRecyclerView() {
        listaPokemonsRecyclerView = findViewById(R.id.pokemon_recyclerview);
        listaPokemonsRecyclerView.setAdapter(adapter);
        listaPokemonsRecyclerView.setHasFixedSize(true);
        gridLayoutManager = new GridLayoutManager(this, 2);
        listaPokemonsRecyclerView.setLayoutManager(gridLayoutManager);
    }

    private void createScrollListener() {
        listaPokemonsRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if(dy > 0){
                    int itemVisivelCount = gridLayoutManager.getChildCount();
                    int totalItemCount = gridLayoutManager.getItemCount();
                    int ultimoItemVisivel = gridLayoutManager.findFirstVisibleItemPosition();
                    //detecta que chegamos ao final da lista e carrega + 20 itens em sua visualização.
                    if((itemVisivelCount + ultimoItemVisivel) >= totalItemCount){
                        isScrolledToEnd = false;
                        offset += 20;
                        getInformacao(offset);
                    }
                }
            }
        });
    }

    private void getInformacao(int offset) {
        isScrolledToEnd = true;
        retrofit.getListaDaAPI(offset, adapter);
    }

    public void buscaPokemon(View view){
        //Em breve funcionará associada à um banco de dados
        Toast.makeText(this, ConstantUtil.POKEMON_NOT_FOUND, Toast.LENGTH_SHORT).show();
    }

    public void scrollUp(View view) {
        LinearLayoutManager layoutManager = (LinearLayoutManager) listaPokemonsRecyclerView.getLayoutManager();
        layoutManager.smoothScrollToPosition(listaPokemonsRecyclerView, null, 0);
    }
}