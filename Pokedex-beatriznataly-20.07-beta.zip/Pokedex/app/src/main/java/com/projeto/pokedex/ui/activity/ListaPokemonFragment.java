package com.projeto.pokedex.ui.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.projeto.pokedex.R;
import com.projeto.pokedex.pokedex.api.PokemonRetrofit;
import com.projeto.pokedex.pokedex.database.PokedexViewModel;
import com.projeto.pokedex.recyclerview.adapter.ListaPokemonAdapter;
import com.projeto.pokedex.util.ConstantUtil;

public class ListaPokemonFragment extends Fragment {
    private View vi;
    private FloatingActionButton fabScroll;
    private ProgressBar spinner;
    private RecyclerView listaPokemonsRecyclerView;
    private  GridLayoutManager gridLayoutManager;
    private PokemonRetrofit retrofit;
    private ListaPokemonAdapter adapter;
    private PokedexViewModel viewModel;
    private boolean isScrolledToEnd;
    private boolean isSearchingPokemons = false;
    private int offset;
    private ImageView arrowBack;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String ultimaBusca = "";

    public ListaPokemonFragment(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        vi = inflater.inflate(R.layout.fragment_lista_pokemon, container, false);
        createLoadingAnimation();
        createRetrofit();
        createRecyclerView();
        createScrollListener();
        createRefreshLayout();
        return vi;
    }

    private void createLoadingAnimation() {
        spinner = vi.findViewById(R.id.spinner_lista_pokemon);
        spinner.setVisibility(View.VISIBLE);

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> spinner.setVisibility(View.GONE), 300);
    }

    private void createRefreshLayout() { //RECARREGA A LISTA DO ZERO E EXIBE O RESULTADO CARREGADO
        swipeRefreshLayout = vi.findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(() -> {
                    listaPokemonsRecyclerView.setVisibility(View.INVISIBLE);
                    scrollUp();
                    createLoadingAnimation();
                    listaPokemonsRecyclerView.setVisibility(View.VISIBLE);
                    if(isSearchingPokemons)
                        buscaPokemon(ultimaBusca);
                    else
                        getInformacao(offset);
                swipeRefreshLayout.setRefreshing(false);
    });
}

    private void createRetrofit() {
        adapter = new ListaPokemonAdapter(getActivity());
        viewModel = ViewModelProviders.of(this).get(PokedexViewModel.class);
        retrofit = new PokemonRetrofit(getContext());
        retrofit.createRetrofit();
        retrofit.setViewModel(viewModel);
        isScrolledToEnd = true;
        offset = 0;
        getInformacao(offset);
       // offset += 20;
    }

    private void createRecyclerView() {
        listaPokemonsRecyclerView = vi.findViewById(R.id.pokemon_recyclerview);
        listaPokemonsRecyclerView.setAdapter(adapter);
        listaPokemonsRecyclerView.setHasFixedSize(true);
        gridLayoutManager = new GridLayoutManager(getContext(), 2);
        listaPokemonsRecyclerView.setLayoutManager(gridLayoutManager);
    }

    private void createScrollListener() {
        listaPokemonsRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if(dy > 0){
                    int itemVisivelCount = gridLayoutManager.getChildCount();
                    int totalItemCount = gridLayoutManager.getItemCount();
                    int ultimoItemVisivel = gridLayoutManager.findFirstVisibleItemPosition();
                    if((itemVisivelCount + ultimoItemVisivel) >= totalItemCount){
                        isScrolledToEnd = false;
                        offset += 20;
                        if(!isSearchingPokemons && retrofit.isConnected())
                        getInformacao(offset);
                    }
                }
            }
        });
    }

    private void getInformacao(int offset) {
        isScrolledToEnd = true;
        retrofit.getListaDaAPI(offset, adapter);
        isSearchingPokemons = false;
    }

    public void buscaPokemon(String busca){
            createLoadingAnimation();
            ultimaBusca = busca;
            retrofit.getBusca(offset, adapter, busca);
            isSearchingPokemons = true;
    }

    public void retornaParaListaPrincipal(){
        adapter.limpaLista();
        offset = 0;
        getInformacao(offset);
        ultimaBusca = "";
        Toast.makeText(getContext(), ConstantUtil.RETURN, Toast.LENGTH_SHORT).show();
    }

    public void scrollUp() {
        LinearLayoutManager layoutManager = (LinearLayoutManager) listaPokemonsRecyclerView.getLayoutManager();
        layoutManager.smoothScrollToPosition(listaPokemonsRecyclerView, null, 0);
    }

}