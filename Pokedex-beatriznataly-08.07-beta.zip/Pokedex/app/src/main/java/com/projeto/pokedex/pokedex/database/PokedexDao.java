package com.projeto.pokedex.pokedex.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.projeto.pokedex.pokedex.entities.Pokemon;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface PokedexDao {
    /*  Não é preciso fazer nenhuma ação;
        O pokémon carregado da lista será exatamente o mesmo e não necessita de substituição.
        Logo podemos simplesmente ignorar a query de insert.
     */

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addPokemon(Pokemon pokemon);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addAllPokemons(List<Pokemon> pokemons);

    @Query("SELECT * FROM tb_pokemon")
    List<Pokemon> getPokemonsDoDatabase();
}
